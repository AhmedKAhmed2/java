
// var degree = window.prompt("enter your degree")


// document.getElementById("massge").innerText ="your grade is ";

// document.getElementById("massge").innerText = degree ;
// if (degree >=50 && degree < 60 )
// {
//     document.getElementById("massge").innerText="your grade is :f";
// } 

// else if (degree >=60 && degree < 70)
// {
//     document.getElementById("massge").innerText = "your grade is : c- ";
// }
// else if (degree >=70 && degree < 75)
// {
//     document.getElementById("massge").innerText = "your grade is : c+ ";
// }
// else if (degree >=75 && degree < 80)

// {
//     document.getElementById("massge").innerText = "your grade is : B ";
// }
// else if (degree >=80 && degree < 85)
// {
//     document.getElementById("massge").innerText = "your grade is : B+ ";
// }
// else if (degree >=90 && degree < 100)

// {
//     document.getElementById("massge").innerText = "your grade is : A ";
// }




// function calcPrice(price,ads,profit,deccount)
// {
//     var finalPrice = price + ads;
//     finalPrice = finalPrice +profit;
//     finalPrice = finalPrice - deccount;

// console.log(finalPrice);
// }

// calcPrice(15,4,5,9)


var list = document.getElementById("dayList");
var month = document.getElementById("monthList");

var cartoona='';
var monthCartoona='';

for ( var day = 1 ; day < 31 ; day++)
{
    cartoona +=`<option value='${day}'>${day}</option>`
}
list.innerHTML = cartoona;



for ( var month= 1 ; month < 13 ; month++)
{
    monthCartoona +=`<option value='${month}'>${month}</option>`
}
console.log(monthCartoona);
monthList.innerHTML = monthCartoona;


var year = document.getElementById("yearList")
var yearCartoona='';
for (var year = 1900 ; year < 2024 ; year ++)
{
    yearCartoona +=`<option value='${year}'>${year}</option>`
}
yearList.innerHTML = yearCartoona;
