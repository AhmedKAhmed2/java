
// var degree = window.prompt("enter your degree")


// document.getElementById("massge").innerText ="your grade is ";

// document.getElementById("massge").innerText = degree ;
// if (degree >=50 && degree < 60 )
// {
//     document.getElementById("massge").innerText="your grade is :f";
// } 

// else if (degree >=60 && degree < 70)
// {
//     document.getElementById("massge").innerText = "your grade is : c- ";
// }
// else if (degree >=70 && degree < 75)
// {
//     document.getElementById("massge").innerText = "your grade is : c+ ";
// }
// else if (degree >=75 && degree < 80)

// {
//     document.getElementById("massge").innerText = "your grade is : B ";
// }
// else if (degree >=80 && degree < 85)
// {
//     document.getElementById("massge").innerText = "your grade is : B+ ";
// }
// else if (degree >=90 && degree < 100)

// {
//     document.getElementById("massge").innerText = "your grade is : A ";
// }




// function calcPrice(price,ads,profit,deccount)
// {
//     var finalPrice = price + ads;
//     finalPrice = finalPrice +profit;
//     finalPrice = finalPrice - deccount;

// console.log(finalPrice);
// }

// calcPrice(15,4,5,9)


// var list = document.getElementById("dayList");
// var month = document.getElementById("monthList");

// var cartoona='';
// var monthCartoona='';

// for ( var day = 1 ; day < 31 ; day++)
// {
//     cartoona +=`<option value='${day}'>${day}</option>`
// }
// list.innerHTML = cartoona;



// for ( var month= 1 ; month < 13 ; month++)
// {
//     monthCartoona +=`<option value='${month}'>${month}</option>`
// }
// console.log(monthCartoona);
// monthList.innerHTML = monthCartoona;


// var year = document.getElementById("yearList")
// var yearCartoona='';
// for (var year = 1900 ; year < 2024 ; year ++)
// {
//     yearCartoona +=`<option value='${year}'>${year}</option>`
// }
// yearList.innerHTML = yearCartoona;



//Number
//double precision ?
//syntactic suger *_*
// e
// **
//Number + bigInt
//Number min value
//number mix value
//(10*10*10*10*10*10)
////////////////////
// console.log(1_000_000);
// console.log(1e6);
// console.log(10**6) ;

// console.log(Number.MAX_SAFE_INTEGER);
// console.log(Number.MAX_VALUE);
// console.log(Number. MAX_VALUE);
////////////

////
//// methods Number
//toString تعامل معامله التيكست
//toFixed تعامل معامله التيكست
//parseInt   تعامل معامله الارقام  تخفي كسور الارقام
//parse float تعامل التيكست ارقام مع الكسور
//isInteger
//isNaN
/////////////////
// console.log((200.10).toString());
// console.log(100.55555.toFixed(2));
// console.log(parseInt("200 Ahmed"));
// console.log(parseFloat("200.555 Ahmed"));
// // تعامل معامله الfales
// console.log(Number.isInteger("200"));
// console.log(Number.isInteger(200.500));
// // تعامل معامله الtrue
// console.log(Number.isInteger(200));
// // تعامل معامله ال True &false
// console.log(Number.isNaN("osama"/ 20));

/////////////////////////////////
//math Object
//Math.round() تقريب الارقام العشريه لرقم صحيح +
//Math.ceil() 
//Math.floor عكس الceil نقص الرقم
//Math.min()
//Math.max()
//Math.pow
//Math.random()
//Math.trunc()
///////
// console.log(Math.round(99.5));
// console.log(Math.ceil(99.5));
// console.log(Math.floor(99.5));
// console.log(Math.min(10,20,100,-100,90));
// console.log(Math.max(10,20,100,-100,90));
// console.log(Math.pow(2,4));
// console.log(Math.random());
// console.log(Math.trunc(99.6));
// console.log(Math.trunc());
//////////


let a = 1_00;
let b = 2_00.5;
let c = 1e2;
let d = 2.4;

// integer
console.log(1_00); //100

//get 2 integer
console.log(1_00); //100
console.log(2_00.5); //200.5
console.log(1e2);//100
console.log( Math.round(2.4) ,Math.ceil(2.4), Math.floor(2.4),Math.trunc(2.4)); //2 round
  //3 ceil
   //2 floor
     //2 trunc

     console.log(a + d * c * b  / d );///10000 a + d
//b+d 66.67=> string
//67=> Number
