var userName = window.prompt("Enter Your Name");


var num1 ="";


document.getElementById("num1").innerText = " Hello GreatingUser" + userName;



